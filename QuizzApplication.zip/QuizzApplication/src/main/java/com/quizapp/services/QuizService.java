package com.quizapp.services;

import com.quizapp.models.Quiz;

public interface QuizService {
	Quiz saveQuiz(Quiz quiz);
	
}
